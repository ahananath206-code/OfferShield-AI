import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
import os
import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
df = pd.read_csv(os.path.join(BASE_DIR, "fake_job_postings.csv"))


df['company_profile'] = df['company_profile'].fillna('')
df['title'] = df['title'].fillna('')
df['description'] = df['description'].fillna('')
df['requirements'] = df['requirements'].fillna('')

df['combined_text'] = df['title'] + " " + df['company_profile'] + " " + df['description'] + " " + df['requirements']

X = df['combined_text']
y = df['fraudulent'] 

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

model_pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english', max_features=5000)),
    ('clf', LogisticRegression(class_weight='balanced', max_iter=1000))
])

print("Model Training...")
model_pipeline.fit(X_train, y_train)

joblib.dump(model_pipeline, 'job_spam_model.pkl')
print("Saved 'job_spam_model.pkl' Successfully! Accuracy:", model_pipeline.score(X_test, y_test))