import os
import joblib
import mysql.connector
from flask import Flask, render_template, request
from werkzeug.utils import secure_filename

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

model = joblib.load('job_spam_model.pkl')

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",     
        password="",       
        database="job_verification_db"
    )

@app.route("/", methods=["GET", "POST"])
def index():
    result_data = None

    if request.method == "POST":
        company = request.form.get("company")
        job_title = request.form.get("job_title")
        description = request.form.get("description")
        
        file = request.files.get("document")
        filename = None
        if file and file.filename != "":
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        input_text = f"{job_title} {company} {description}"
        
        probabilities = model.predict_proba([input_text])[0]
        spam_prob = round(probabilities[1] * 100, 2)
        
        is_spam = "Spam / Fake Offer" if spam_prob >= 50 else "Not Spam (Legitimate)"

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            sql = """
                INSERT INTO verification_logs 
                (company_name, job_title, description, document_name, prediction_result, spam_percentage) 
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            values = (company, job_title, description, filename, is_spam, spam_prob)
            cursor.execute(sql, values)
            conn.commit()
            cursor.close()
            conn.close()
        except Exception as e:
            print("Database Error:", e)

        result_data = {
            "status": is_spam,
            "spam_percentage": spam_prob,
            "is_danger": spam_prob >= 50
        }

    return render_template("index.html", result=result_data)

if __name__ == "__main__":
    app.run(debug=True)